# AI Infrastructure Curriculum → InferX

A ~7-month self-directed curriculum (26 content weeks + 3 buffer weeks, 12–15 h/week) from systems foundations to a hand-built LLM inference engine, **InferX**, benchmarked against vLLM and SGLang.

```
Month 1  Systems foundations      C++ · Linux · Networking · Performance
Month 2  Distributed systems      Failure · Replication · Scheduling · Task queue
Month 3  GPU + PyTorch            GPU architecture · CUDA · PyTorch internals · Triton
Month 4  Distributed training     DDP · NCCL · FSDP · Tensor parallelism
Month 5  LLM inference            Model · KV cache · Continuous batching · Serving
Month 6  Serving systems          vLLM · PagedAttention · Triton attention
Capstone                          SGLang + prefix caching · InferX v1.0 · Benchmark report
```

**Goal:** be able to read an AI infrastructure system, understand where its compute / memory / communication bottlenecks come from, reproduce a simplified version, benchmark it, and make a principled optimization.

## Documents
- [Design doc](docs/DESIGN.md) — principles, structure, progress system, InferX architecture, benchmark methodology
- [Curriculum](docs/CURRICULUM.md) — week-by-week specs
- [Question bank](docs/QUESTIONS.md) — what I should be able to explain and demonstrate
- [Reading list](docs/READING.md) — scoped books and papers
- [Progress](PROGRESS.md) — tracker
- [Reports](reports/) — performance reports

## Working with Claude Code
See [CLAUDE.md](CLAUDE.md). Commands: `/start-week N`, `/review`, `/quiz`, `/checkpoint N`, `/perf-report <project>`.
